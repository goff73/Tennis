﻿angular.module('profitSearch', []).controller('profitSearchCtrl', function ($scope) {
    $scope.names = [
        { relationshipname: 'Goff, Bryan', relationshipnumber: '00034' , profit: '232.22', profitr12:'5000.00', instranking:'1', roa:'23.44', rol:'12.33', roe:'21.44', asset:'50000', liability:'300' },
        { relationshipname: 'Dorko, Brian', relationshipnumber: '1232', profit: '500.33', profitr12: '8000.00', instranking: '5', roa: '0', rol: '22.22', roe: '21.44', asset: '0', liability: '3000000' },
        { relationshipname: 'Goff, Bostwick', relationshipnumber: '13122', profit: '-50515', profitr12: '-5055555', instranking: '10000', roa: '-21.33', rol: '-12.33', roe: '-21.44', asset: '100000', liability: '50' }
    ];
});